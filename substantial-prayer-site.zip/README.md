# Substantial Prayer — React (Vite) Starter

This is a ready-to-deploy React app for **substantialprayer.com**. It includes your layout, styles, and a Prayer Request form.

## Quick Start (Local)

```bash
npm install
npm run dev
# open the URL shown (usually http://localhost:5173)
```

> Tailwind is loaded via CDN in `index.html` so you can edit classes without extra setup.

## Deploy (Vercel)

1. Create a new Vercel project and import this folder (or push to GitHub and import).
2. Framework preset: **Vite**.
3. Build command: `npm run build`
4. Output directory: `dist`
5. Point your domain (e.g., substantialprayer.com) to Vercel per their DNS instructions.

## Deploy (Netlify)

1. New site from Git → choose your repo.
2. Build command: `npm run build`
3. Publish directory: `dist`
4. Set domain in Netlify Domain settings (or add custom domain).

## Editing

- Main component lives in `src/App.jsx`. Edit JSX/Tailwind classes freely.
- Background symbols and aura are in the top of the component.
- To receive prayer requests, set `PRAYER_ENDPOINT` in `src/App.jsx` to Formspree, Netlify Function, Vercel Serverless, or Zapier Webhook.

### Example (Formspree)
- Create a form at https://formspree.io
- Replace `const PRAYER_ENDPOINT = ""` with your endpoint, e.g.
  ```js
  const PRAYER_ENDPOINT = "https://formspree.io/f/xxxxxxx";
  ```

## Notes

- Product images are placeholders. Replace the "Product Image" area with <img> tags or background images.
- This project uses CDN Tailwind to keep it simple; you can switch to a full Tailwind build later if you prefer.
