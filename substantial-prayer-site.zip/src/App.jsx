import React, { useState } from "react";

function validatePrayerPayload(payload) {
  const hasName = typeof payload?.name === "string" && payload.name.trim().length > 0;
  const hasRequest = typeof payload?.request === "string" && payload.request.trim().length > 0;
  const emailOk = !payload?.email || /.+@.+\..+/.test(payload.email);
  return hasName && hasRequest && emailOk;
}

export default function App() {
  const PRAYER_ENDPOINT = ""; // Hook up later (Formspree/Netlify/Vercel function/Zapier)
  const [status, setStatus] = useState({ ok: false, error: "" });

  async function handlePrayerSubmit(e) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = Object.fromEntries(new FormData(form).entries());

    if (!validatePrayerPayload(data)) {
      setStatus({ ok: false, error: "Please provide your name, a valid email (optional), and a prayer request." });
      return;
    }

    try {
      if (PRAYER_ENDPOINT) {
        await fetch(PRAYER_ENDPOINT, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        });
      }
      setStatus({ ok: true, error: "" });
      form.reset();
    } catch (err) {
      setStatus({ ok: false, error: "Something went wrong. Please try again." });
    }
  }

  return (
    <div className="min-h-screen text-white bg-gradient-to-b from-black via-[#0b0b0b] to-black font-extralight tracking-wide relative overflow-hidden">
      {/* AURA FIELD (static, neutral) */}
      <div className="absolute inset-0 -z-20 pointer-events-none">
        <div className="absolute left-1/2 top-[-20%] -translate-x-1/2 w-[1300px] h-[1300px] rounded-full bg-white/12 blur-[200px]"></div>
        <div className="absolute right-[-10%] bottom-[-20%] w-[1000px] h-[1000px] rounded-full bg-white/8 blur-[180px]"></div>
      </div>

      {/* SYMBOL FIELD (static, neutral) */}
      <div className="absolute inset-0 -z-10 opacity-[0.06] pointer-events-none">
        <svg viewBox="0 0 1200 800" className="w-full h-full">
          {[
            { x: 100, y: 140, t: "☧" },
            { x: 320, y: 300, t: "Α" },
            { x: 380, y: 300, t: "Ω" },
            { x: 620, y: 180, t: "✠" },
            { x: 900, y: 260, t: "†" },
            { x: 1040, y: 520, t: "☧" },
            { x: 220, y: 560, t: "Ω" },
            { x: 560, y: 640, t: "Α" },
          ].map((s, i) => (
            <text key={i} x={s.x} y={s.y} fontSize="64" fill="#ffffff" opacity="0.5">{s.t}</text>
          ))}
        </svg>
      </div>

      <style>{`
        @keyframes marquee {0%{transform:translateX(0)}100%{transform:translateX(-50%)}}
      `}</style>

      {/* MARQUEE SCRIPTURE STRIP */}
      <div className="sticky top-0 z-50 w-full bg-white/5 backdrop-blur border-b border-white/10 text-xs uppercase tracking-[0.35em] whitespace-nowrap overflow-hidden">
        <div className="animate-[marquee_30s_linear_infinite] py-2">
          <span className="mx-8 opacity-80">1 Thessalonians 5:17 — Pray without ceasing.</span>
          <span className="mx-8 opacity-80">Matthew 6:6 — Enter your room and pray to your Father.</span>
          <span className="mx-8 opacity-80">Mark 11:24 — Whatever you ask in prayer, believe.</span>
          <span className="mx-8 opacity-80">Psalm 141:2 — Let my prayer be set before You as incense.</span>
        </div>
      </div>

      {/* HEADER (no nav options, neutral halo) */}
      <header className="py-8 text-center border-b border-white/10 backdrop-blur bg-black/30 sticky top-[28px] z-40 relative">
        <div aria-hidden className="pointer-events-none absolute inset-0 -z-10 flex items-center justify-center">
          <div className="h-28 w-72 rounded-full bg-white/15 blur-3xl"></div>
        </div>
        <h1 className="text-4xl md:text-6xl font-extralight tracking-[0.4em] drop-shadow-[0_0_28px_rgba(255,255,255,0.9)]">SUBSTANTIAL PRAYER</h1>
        <p className="mt-2 text-sm md:text-base uppercase tracking-[0.45em] text-white/80">Pray About It</p>
      </header>

      {/* MAIN CONTENT — EXACT LAYOUT */}
      <main className="mx-auto max-w-7xl px-6 grid grid-cols-1 lg:grid-cols-12 gap-10 mt-10">
        {/* SHOP GRID */}
        <section id="shop" className="lg:col-span-8 order-2 lg:order-1">
          <div className="flex items-end justify-between mb-6">
            <h2 className="text-2xl md:text-3xl font-extralight tracking-[0.35em] drop-shadow-[0_0_14px_rgba(255,255,255,0.8)]">Shop the Collection</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
            {[
              { name: "Armor of God Hoodie", verse: "Ephesians 6:11", price: "$75" },
              { name: "Light of the World Tee", verse: "Matthew 5:14", price: "$50" },
              { name: "Faith Over Fear Crew", verse: "Isaiah 41:10", price: "$65" },
              { name: "Pray Without Ceasing Cap", verse: "1 Thess. 5:17", price: "$35" },
            ].map((item, i) => (
              <article key={i} className="group overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-black/80 to-black/60 shadow-[0_0_40px_rgba(255,255,255,0.15)] hover:shadow-[0_0_60px_rgba(255,255,255,0.25)] transition">
                {/* Product image box sized to image */}
                <div className="relative flex items-center justify-center bg-white/5 text-white/30" style={{ width: '100%', height: '250px' }}>
                  Product Image
                  <div className="pointer-events-none absolute inset-0 opacity-0 group-hover:opacity-100 transition" style={{ boxShadow: 'inset 0 0 80px rgba(255,255,255,0.15)' }}></div>
                </div>
                <div className="p-5">
                  <h3 className="font-extralight tracking-[0.25em] text-lg drop-shadow-[0_0_10px_rgba(255,255,255,0.6)]">{item.name}</h3>
                  <p className="text-xs italic text-white/60">“{item.verse}”</p>
                  <div className="mt-3">
                    <label className="block text-[10px] text-white/60 mb-1">Size</label>
                    <select className="w-full bg-black/40 border border-white/20 rounded-lg p-2 text-xs focus:outline-none">
                      <option>Small</option>
                      <option>Medium</option>
                      <option>Large</option>
                      <option>XL</option>
                    </select>
                  </div>
                  <div className="mt-3 flex items-center justify-between">
                    <span className="text-white/90">{item.price}</span>
                    <button className="px-4 py-2 bg-white text-black rounded-lg text-xs tracking-wide hover:opacity-90">Add to Cart</button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>

        {/* PRAYER REQUESTS SIDEBAR */}
        <aside id="requests" className="lg:col-span-4 order-1 lg:order-2 lg:sticky lg:top-36 self-start">
          <div className="rounded-2xl border border-white/10 bg-white/5 p-6 shadow-[0_0_24px_rgba(255,255,255,0.25)] relative overflow-hidden">
            {/* faint symbol watermark inside card */}
            <div aria-hidden className="pointer-events-none absolute -right-6 -bottom-8 text-6xl opacity-[0.08]">☧</div>
            <h3 className="text-sm uppercase tracking-[0.4em] text-white/80 mb-4">Prayer Requests</h3>
            <p className="text-white/80 text-sm leading-relaxed mb-4">Share your name and request. We’ll lift it up in prayer.</p>
            <form onSubmit={handlePrayerSubmit} className="space-y-3">
              <div>
                <label className="block text-[11px] text-white/60 mb-1">Name</label>
                <input name="name" required placeholder="Your name" className="w-full bg-black/40 border border-white/20 rounded-lg p-2 text-sm focus:outline-none" />
              </div>
              <div>
                <label className="block text-[11px] text-white/60 mb-1">Email (optional)</label>
                <input type="email" name="email" placeholder="you@email.com" className="w-full bg-black/40 border border-white/20 rounded-lg p-2 text-sm focus:outline-none" />
              </div>
              <div>
                <label className="block text-[11px] text-white/60 mb-1">Prayer Request</label>
                <textarea name="request" required rows={4} placeholder="How can we pray for you?" className="w-full bg-black/40 border border-white/20 rounded-lg p-2 text-sm focus:outline-none" />
              </div>
              <button type="submit" className="w-full px-4 py-2 bg-white text-black rounded-lg text-xs tracking-wide hover:opacity-90">Send Request</button>
              {status.ok && <p className="text-emerald-300 text-xs">Thank you. Your request has been received.</p>}
              {status.error && <p className="text-red-300 text-xs">{status.error}</p>}
              <p className="text-[10px] text-white/50">Configure <span className="font-medium">PRAYER_ENDPOINT</span> to forward requests to your email or database.</p>
            </form>
          </div>
        </aside>
      </main>

      {/* CART SECTION AT BOTTOM */}
      <section id="cart" className="mt-16 mb-20">
        <div className="mx-auto max-w-7xl px-6">
          <div className="rounded-3xl border border-white/10 bg-gradient-to-r from-black/70 to-white/5 p-6 md:p-8 relative overflow-hidden">
            <div aria-hidden className="absolute -left-6 -top-8 text-7xl opacity-[0.06]">Α Ω</div>
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div className="flex-1">
                <h3 className="text-lg font-extralight tracking-[0.3em] mb-2">Your Cart</h3>
                <p className="text-sm text-white/70">One step from sacred drip. Review items and check out.</p>
              </div>
              <div className="w-full md:w-auto space-y-3">
                <div className="flex items-center justify-between rounded-xl border border-white/10 bg-black/40 px-4 py-3">
                  <div>
                    <p className="text-sm">Prayer Hoodie — M</p>
                    <p className="text-xs text-white/60">Eph 6:11</p>
                  </div>
                  <span>$75</span>
                </div>
                <button className="w-full md:w-auto px-6 py-3 bg-white text-black rounded-xl text-sm tracking-wide hover:opacity-90">Checkout</button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
